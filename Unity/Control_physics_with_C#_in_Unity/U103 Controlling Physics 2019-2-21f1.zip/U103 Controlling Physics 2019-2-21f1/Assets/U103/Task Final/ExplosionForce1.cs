﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof (Collider))]
public class ExplosionForce1 : MonoBehaviour
{
  public  float radius;
  public  float power;
  public  float lift;
    
  private void OnCollisionEnter (Collision other)
  {
    ApplyExplosionForce ();
    Destroy (gameObject);
  }

  private void ApplyExplosionForce ()
  {
    Vector3    explosionPos = transform.position;
    Collider[] colliders = Physics.OverlapSphere (explosionPos, radius);
    foreach (Collider hit in colliders)
    {
      Rigidbody rb = hit.GetComponent<Rigidbody> ();
      if (rb != null)
      {
        rb.AddExplosionForce (power, explosionPos, radius, lift);
      }
    }
  }
}

