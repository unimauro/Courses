﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ForceMovement1 : MonoBehaviour
{
    public Rigidbody target;
    public float magnitude;
    public ForceMode forceMode;
    
    void FixedUpdate ()
    {
        ProcessKBInput ();
    }

    private void ProcessKBInput ()
    {
        if (Input.GetKey (KeyCode.Space))
        {
            target.AddForce (Vector3.up * magnitude, forceMode);
        }

        if (Input.GetKey (KeyCode.A))
        {
            target.AddForce (Vector3.left * magnitude, forceMode);
        }

        if (Input.GetKey (KeyCode.D))
        {
            target.AddForce (Vector3.right * magnitude, forceMode);
        }

        if (Input.GetKey (KeyCode.W))
        {
            target.AddForce (Vector3.forward * magnitude, forceMode);
        }

        if (Input.GetKey (KeyCode.S))
        {
            target.AddForce (Vector3.back * magnitude, forceMode);
        }
    }
}
