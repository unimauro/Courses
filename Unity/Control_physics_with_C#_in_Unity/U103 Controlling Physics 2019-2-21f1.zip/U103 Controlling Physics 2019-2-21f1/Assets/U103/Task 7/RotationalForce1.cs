﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotationalForce1 : MonoBehaviour
{
	public Rigidbody target;
	public float     torque;
	public ForceMode forceMode;

	private void Start ()
	{
		target.maxAngularVelocity = Mathf.Infinity;
	}

	void FixedUpdate ()
	{
		ProcessKBInput ();
	}

	private void ProcessKBInput ()
	{
		if (Input.GetKey (KeyCode.E))
		{
			target.AddTorque(Vector3.up * torque, forceMode);
		}

		if (Input.GetKey (KeyCode.R))
		{
			target.AddTorque (Vector3.up * -torque, forceMode);
		}
	}
}
